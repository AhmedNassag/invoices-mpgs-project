<?php
namespace App\Enums;

enum TaxStatus
{
    const ACTIVE   = 5;
    const INACTIVE = 10;
}
