<?php

namespace App\Enums;

enum InvoiceType
{
    const INVOICE = 5;
    const QUOTATION = 10;
}