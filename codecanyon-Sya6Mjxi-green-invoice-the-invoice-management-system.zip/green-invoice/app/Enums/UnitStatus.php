<?php

namespace App\Enums;

enum UnitStatus
{
    const ACTIVE = 5;
    const INACTIVE = 10;
}
