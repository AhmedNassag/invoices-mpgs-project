<?php

namespace App\Enums;

enum MediaType
{
    const INVOICE = 5;
    const USER = 10;
}