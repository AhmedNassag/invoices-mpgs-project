<?php

namespace App\Enums;

enum TaxRateStatus
{
    const ACTIVE = 5;
    const INACTIVE = 10;
}
