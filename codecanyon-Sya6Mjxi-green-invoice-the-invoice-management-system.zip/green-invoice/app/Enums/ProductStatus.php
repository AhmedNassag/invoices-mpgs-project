<?php

namespace App\Enums;

enum ProductStatus
{
    const ACTIVE = 5;
    const INACTIVE = 10;
}
