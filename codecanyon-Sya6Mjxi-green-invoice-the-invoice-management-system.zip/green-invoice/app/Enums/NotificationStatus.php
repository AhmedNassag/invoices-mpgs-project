<?php

namespace App\Enums;

enum NotificationStatus
{
    const UNREAD = 5;
    const READ = 10;
    const DELETE = 15;
}