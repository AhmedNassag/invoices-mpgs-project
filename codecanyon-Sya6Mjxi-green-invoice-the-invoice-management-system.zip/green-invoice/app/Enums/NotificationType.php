<?php

namespace App\Enums;

enum NotificationType
{
    const CREATED = 5;
    const UPDATED = 10;
    const DELETED = 15;
}