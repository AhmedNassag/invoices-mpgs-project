@include('backend.components._page_header')

@yield('content')

@include('backend.components._page_footer')