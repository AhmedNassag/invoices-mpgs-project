<?php

return [
    'app_name' => 'green-invoice',
    'app_version' => 2.5,
    'app_demo' => env('APP_DEMO', false),
    'app_author_url' => env('APP_AUTHOR_URL', 'https://schema.greensoftbd.net'),
    'app_purchase_code' => env('APP_PURCHASE_CODE')
];